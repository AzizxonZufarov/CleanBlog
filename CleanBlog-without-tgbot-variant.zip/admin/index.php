
<? include "inc/bd.php";?>

<? include "inc/header.php";?>

<? include "inc/left.php";?>
  
  
    <div id="templatemo_right_column">
    
    	<div id="featured_project">
            <div id="slider">
               
            </div>
        </div>
        
        <div id="templatemo_main">
 
             <h2>Hello, admin</h2>
		</div>
    
  <div class="cleaner"></div>
  </div> 
    <!-- end of templatemo_main -->
  <div class="cleaner_h20"></div>
  


<? include "inc/footer.php";?>
  
 
  
