  	<div id="templatemo_footer">

		Copyright © <?php echo(date("Y"));?>  <a href="#">Testcoder.uz</a> |
        <a href="Testcoder.uz" target="_parent">CleanBlog</a> 

    </div>
    <div class="cleaner"></div>
</div> <!-- end of warpper -->

</body>
</html>
